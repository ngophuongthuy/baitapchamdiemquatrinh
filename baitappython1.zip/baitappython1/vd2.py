a = input()
b = input()

if a > b:
  print("a lon hon b")
else:
  print("a be hon b")
